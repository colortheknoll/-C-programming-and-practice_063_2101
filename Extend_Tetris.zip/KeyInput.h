#pragma once

class KeyInput
{

};

