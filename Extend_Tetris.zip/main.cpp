#pragma once

#include "Tetris.h"
#include <iostream>

int main() {

	Tetris tetris;
	tetris.run();
}
